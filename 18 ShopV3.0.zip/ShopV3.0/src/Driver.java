import java.util.Scanner;

public class driver {
    private Store store;
    private Scanner input = new Scanner(System.in);

    public void Driver() {
        store = new Store();
        runMenu();
    }

    private int mainMenu(){
        System.out.print(""" 
Shop Menu --------- 
1) Add a product 
2) List the Products ---------------------------- 
3) List the current products 
4) Display average product unit cost 
5) Display cheapest product 
6) List products that are more expensive than a 
given price ---------------------------- 
0) Exit 
==>>  """);
        int option = input.nextInt();
        return option;
    }
    private void runMenu(){
        int option = mainMenu();
        while (option != 0){
            switch (option){
                case 1 -> addProduct();
                case 2 -> printProducts();
                case 3 -> printCurrentProducts();
                case 4 -> printAverageProductPrice();
                case 5 -> printCheapestProduct();
                case 6 -> printProductsAboveAPrice();
                default -> System.out.println("Invalid option entered: " + option);
            }
//pause the program so that the user can read what wejust printed to the terminal window
            System.out.println("\nPress enter key to continue...");
            input.nextLine();
            input.nextLine(); //second read is required - bug inScanner class; a String read is ignored straight after reading anint.
//display the main menu againoption = mainMenu();
        }
//the user chose option 0, so exit the program
        System.out.println("Exiting...bye");
        System.exit(0);
    }

    private void processOrder() {
        input.nextLine();
        System.out.print("How many Products would you like to have in your Store? ");
        int numberProducts = input.nextInt();
        for (int i = 0; i < numberProducts; i++) {
            addProduct();
        }
    }

    private void addProduct() {
        input.nextLine();  //dummy read of String to clear thebuffer - bug in Scanner class.
        System.out.print("Enter the Product Name:  ");
        String productName = input.nextLine();
        System.out.print("Enter the Product Code:  ");
        int productCode = input.nextInt();
        System.out.print("Enter the Unit Cost:  ");
        double unitCost = input.nextDouble();
//Ask the user to type in either a Y or an N.  This is then
//converted to either a True or a False (i.e. a booleanvalue).
        System.out.print("Is this product in your current line (y/n): ");
        char currentProduct = input.next().charAt(0);
        boolean inCurrentProductLine = false;
        if ((currentProduct == 'y') || (currentProduct == 'Y'))
            inCurrentProductLine = true;
        boolean isAdded = store.add(new Product(productName, productCode, unitCost, inCurrentProductLine));
        if (isAdded) {
            System.out.println("Product Added Successfully");
        } else {
            System.out.println("No Product Added");
        }
    }

    public void printCurrentProduct() {

    }
    private void  printAverageProductPrice(){

        double averagePrice = store.averageProductPrice();
        if (averagePrice == -1) {
            System.out.println("There are no products in the store, average product price is: -1");
        } else {
            System.out.println("Average product price is: " + averagePrice);
        }
    }

    private void printCheapestProduct() {
        Product cheapest = store.cheapestProduct();
        if (cheapest == null) {
            System.out.println("There are no products in the store.");
        } else {
            System.out.println("The cheapest product is: " + cheapest.getName());
        }
    }

    private void printProductsAboveAPrice() {
        System.out.print("View the products costing more than this price: ");
        double price = input.nextDouble();
        System.out.println(store.listProductsAboveAPrice(price));
    }

    public void printProducts() {
    }

    public void printCurrentProducts() {
    }
}

public void main(String[] args) {
    driver driver = new driver();
    driver.processOrder();
    driver.printProducts();
    driver.printCurrentProducts();
    driver.printAverageProductPrice();
    driver.printCheapestProduct();
    driver.printProductsAboveAPrice();
    driver.input.close();
}
private int mainMenu(){
    System.out.print(""" 
Shop Menu --------- 
1) List the Products 
2) List the current products 
3) Display average product unit cost 
4) Display cheapest product 
5) List products that are more expensive than a 
given price 
0) Exit 
==>> """);
    Scanner input = new Scanner(System.in);
    int option = input.nextInt();
    return option;
}
public void runMenu(){
    int option = mainMenu();
    while (option != 0){
        switch (option){
            case 1 -> printProducts();
            case 2 -> printCurrentProducts();
            case 3 -> printAverageProductPrice();
            case 4 -> printCheapestProduct();
            case 5 -> printProductsAboveAPrice();
            default -> System.out.println("Invalid option entered: " + option);
        }
//pause the program so that the user can read what wejust printed to the terminal window
        System.out.println("\nPress enter key to continue...");
        Scanner input = new Scanner(System.in);
        input.nextLine();
        input.nextLine(); //second read is required - bug inScanner class; a String read is ignored straight after reading anint.
//display the main menu again
        option = mainMenu();
    }
//the user chose option 0, so exit the program
    System.out.println("Exiting...bye");
    System.exit(0);
}

private void printProductsAboveAPrice() {
}

private void printCheapestProduct() {
}

private void printAverageProductPrice() {
}

private void printCurrentProducts() {
}

private void printProducts() {
}

