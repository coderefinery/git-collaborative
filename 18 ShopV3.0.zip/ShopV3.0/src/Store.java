import java.util.ArrayList;

public class Store {
    private ArrayList<Product> products;

    public Store() {
        products = new ArrayList<>();
    }

    public boolean add(Product product) {
        return products.add(product);
    }

    public String listProducts() {
        if (products.isEmpty()) {
            return "No products in the store";
        }
        String listOfProducts = "";
        int index = 0;
        for (Product product : products) {
            listOfProducts += index + ": " + product + "\n";
            index++;
        }
        return listOfProducts;
    }

    public String listCurrentProducts() {
        if (products.isEmpty()) {
            return "No products in the store";
        }
        String listOfProducts = "";
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).isInCurrentProductLine()) {
                listOfProducts += i + ": " + products.get(i) + "\n";
            }
        }
        return listOfProducts.isEmpty()? "No products in the current product line" : listOfProducts;
    }

    public String listProductsAboveAPrice(double price) {
        if (products.isEmpty()) {
            return "No products in the store";
        }
        String listOfProducts = "";
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getUnitCost() > price) {
                listOfProducts += i + ": " + products.get(i) + "\n";
            }
        }
        return listOfProducts.isEmpty()? "No products above the given price" : listOfProducts;
    }

    public double averageProductPrice() {
        if (products.isEmpty()) {
            return -1;
        }
        double totalPrice = 0;
        for (Product product : products) {
            totalPrice += product.getUnitCost();
        }
        return totalPrice / products.size();
    }
    public Product cheapestProduct() {
        if (!products.isEmpty()) {
            Product cheapestProduct = products.get(0);
            for (Product product : products) {
                if (product.getUnitCost() <
                        cheapestProduct.getUnitCost())
                    cheapestProduct = product;
            }
            return cheapestProduct;
        } else {
            return null;
        }
    }
}